package com.example.learnkotlin

// Design Principle and Best Practices
//      Classes Which Are Not Meant To Be Inherited Must Be Final
//      Functions Which Are Not Meant To Be Overriden Must Be Final

// In Kotlin
//      Classes And Member Functions Are Final By Default
//      i.e. Closed For Inheritance

// In Java
//      Classes And Member Functions Are Open By Default
//      i.e. Open For Inheritance

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

open class View {
   open fun click() = println("View Clicked!!!")
}

// Inheritance Creates
//      Relationships Between Types
//          Type of Type Relationship
class Button : View() { // Inheritance
    override fun click() = println("Button Clicked!!!")
    fun doMagic() = println("Button Magic...")
}

// Extension Functions Are Bound With Type
//      Extension Functions Can't Be Overridden By Inherited Type

fun View.showOff()   = println("View ShowOff...")
fun Button.showOff() = println("Button ShowOff...")

fun playWithClasses() {
    // 1. Type Inferencing From RHS
    // 2. Type Binding To LHS

    // Following Both Lines Are Equivalent
//    val view : View = View()
    val view  = View()
    view.click()

    // Following Both Lines Are Equivalent
//    val button : Button = Button()
    val button = Button()
    button.click()
    button.doMagic()

    // Parent Type Will Set The Perceptives
    // Following Both Lines Are Not Same
    val viewAgain: View = Button() // Explicitly Annotating Type To View
//    val viewAgain = Button()

    viewAgain.click()
    //viewAgain.doMagic()

//    fun View.showOff()   = println("View ShowOff...")
//    fun Button.showOff() = println("Button ShowOff...")
    view.showOff()
    button.showOff()
    viewAgain.showOff()

//    View ShowOff...
//    Button ShowOff...
//    View ShowOff...
}

// In Kotlin
//      Interfaces And Member Functions Are Opem By Default
//      Implementing Class Must Override It
//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

interface Clickable {
    fun click()
    fun showOff() = println("Clickable ShowOff...")
}

interface Focusable {
    // Provide Default Implementation Only In Rarest Rare Case
    fun setFocus() = println("Focusable setFocus...") // Default Implementation
    fun showOff()  = println("Focusable ShowOff...")
}

open class ButtonAgain : Clickable, Focusable {
    override fun click() = println("ButtonAgain Clicked!!!")
    override fun showOff() {
        // Pick Based On Your Own Custom Logic
        super<Focusable>.showOff()
        super<Clickable>.showOff()
    }
}

open class RichButton : ButtonAgain() {
    final override fun click() = println("RichButton Clicked!!!")
}

class ExtensiveRichButton : RichButton() {
//    override fun click() = println("RichButton Clicked!!!")
//    fun click() = println("RichButton Clicked!!!")
}

fun playWihInterfaces() {
    val button = ButtonAgain()
    button.click()
    button.setFocus()
    button.showOff()

    val richButton = RichButton()
    richButton.click()
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// In Java/Kotlin Every Class By Default Subclass Of Object Class
//      toString(), equals() and hashCode() Methods Comes From Object Class
//      equals() and hashCode() Both Methods Must Be Overridden Together
class Client(val name: String, val postalCode: Int)  {
    override fun toString() = "Client(name=$name, postalCode=$postalCode)"

    override fun equals(other: Any?) : Boolean {
        if (other == null || other !is Client ) return false
        return name == other.name && postalCode == other.postalCode
    }
    // If You Are Overriding equals() Method
    // Than You Must Override hashCode() Method Also
}

fun playWithClientClass() {
    val client1 = Client("Alice", 77777 )
    val client2 = Client("Alice", 77777 )
    val client3 = Client("Alisha", 88888 )

    println(client1) // println Invokes client1.toString()
//    println(client1.name)
//    println(client1.postalCode)
    println(client2) // println Invokes client2.toString()
    println(client3) // println Invokes client3.toString()
//    com.example.learnkotlin.Client@506e6d5e
//    com.example.learnkotlin.Client@96532d6
//    com.example.learnkotlin.Client@3796751b

    // By Default
    // Equality Operator Will Compare References Of The Objects
    // To Compare Objects Based On Properties
    //      Must Override equals() Method
    // Expected True
    // Expected False
    println( client1 == client2 ) // client1.equals(client2)
    println( client1 == client3 ) // client1.equals(client3)
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// Data Class
// For Data Classes
//      Compiler Will Generate Following Methods Code
//      toString(), equals(), hashCode() and
//      copy() Method Code Generated For Immutable Properties
//          Based On All The Properties
data class ClientAgain(val name: String, val postalCode: Int)

fun playWithClientAgainDataClass() {
    val client1 = ClientAgain("Alice", 77777 )
    val client2 = ClientAgain("Alice", 77777 )
    val client3 = ClientAgain("Alisha", 88888 )

    println(client1) // println Invokes client1.toString()
    println(client2) // println Invokes client2.toString()
    println(client3) // println Invokes client3.toString()

    println( client1 == client2 ) // client1.equals(client2)
    println( client1 == client3 ) // client1.equals(client3)
}

//________________________________________________________

// RED, GREEN, BLUE and so on Are Instances Of enum ColorAgain Class

enum class ColorAgain(val r: Int, val g: Int, val b: Int) {
    RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255),
    ORANGE(200, 200, 200), YELLOW(100, 100, 100), UNKNOWN(0, 0, 0)  ;

    fun rgb() = ( r * 255 + g ) * 256 + b
}

fun playWithColors() {
    println( ColorAgain.RED )
    println( ColorAgain.RED.r )
    println( ColorAgain.RED.g )
    println( ColorAgain.RED.b )
    println( ColorAgain.GREEN )
    println( ColorAgain.ORANGE )

    println( ColorAgain.RED.rgb())
    println( ColorAgain.ORANGE.rgb())
}

// Type Diagram
//interface Message
//interface ExceptionMessage : Message
//interface SuccessMessage: Message
//
//enum class Response(message: Message) {
//    SUCCESS(message = ), FAILURE(message = )
//    SUCCESS(message = ), FAILURE(message = )
//}

//________________________________________________________

// States Related To SUM
// States Related To NUM

//enum class ExprType() {
//    SUM(), NUM()
//}

// Defining Type Expr
interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr

fun eval(e: Expr) : Int {
    // Type Of e Is Expr
    if (e is Num) { // Smart Cast
        // Type Of e Is Num
        return e.value
    }
    // Type Of e Is Expr
    if (e is Sum) {
        // Type Of e Is Sum
        return eval( e.left ) + eval( e.right )
    }
    throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEval() {
    // 100 + 200
    println( eval ( Sum( Num(100), Num(200)) ))
}

//________________________________________________________

fun evalIfAgain(e: Expr) : Int = if (e is Num) {
        e.value
    } else if (e is Sum) {
    evalIfAgain( e.left ) + evalIfAgain( e.right )
    } else {
        throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvalIfAgain() {
    // 100 + 200
    println( evalIfAgain ( Sum( Num(100), Num(200)) ))
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

//interface Expr
//class Num(val value: Int) : Expr
//class Sum(val left: Expr, val right: Expr) : Expr

fun evaluateAgain(e: Expr) : Int = when (e) {
    is Num ->  e.value
    is Sum -> evaluateAgain( e.left ) + evaluateAgain( e.right )
    else   -> throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvaluateAgain() {
    // 100 + 200
    println( evaluateAgain ( Sum( Num(100), Num(200)) ))
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

sealed class ExprAgain {
    class Num(val value: Int) : ExprAgain()
    class Sum(val left: ExprAgain, val right: ExprAgain) : ExprAgain()
}

// Following Code Type Safe
fun evaluateAgainSealed(e: ExprAgain) : Int = when (e) {
    is ExprAgain.Num ->  e.value
    is ExprAgain.Sum -> evaluateAgainSealed( e.left ) + evaluateAgainSealed( e.right )
//    else   -> throw IllegalArgumentException("Unknown Arguments...")
}

fun playWithEvaluateAgainUsingSealedClases() {
    // 100 + 200
    println( evaluateAgainSealed ( ExprAgain.Sum( ExprAgain.Num(100), ExprAgain.Num(200)) ))
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

sealed class Geometry {
    class Circle(val radius: Int) : Geometry()
    class Square(val side: Int) : Geometry()
}

fun sizeOfGeometry(geometry: Geometry) = when ( geometry ) {
    is Geometry.Circle -> geometry.radius
    is Geometry.Square -> geometry.side
}

fun playWithGeometries() {
    val circle1 = Geometry.Circle(10)
    val circle2 = Geometry.Circle(20)
    println( sizeOfGeometry( circle1 ) )
    println( sizeOfGeometry( circle2 ) )

    val square1 = Geometry.Square(30)
    val square2 = Geometry.Square(40)
    println(sizeOfGeometry(square1))
    println(sizeOfGeometry(square2))
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// In Kotlin Classes Are By Default Nested
// Nested Classes
//      Class Defined Inside A Class
//      Nested Class Can't Capture Outer Class Context
class Car(val carName: String) { // Outer Class Context i.e. Enclosing Context
    val category: String = "Family Car"
    override fun toString(): String {
        return "$carName"
    }
    // Nested Class
    // Class Defined Inside A Class
    class Engine(val engineName: String) { // Nested Class Context i.e. Enclosed Context
        override fun toString(): String {
//            return "Car $carName Have $engineName And $category"
            return "Car $engineName"
        }
    }
}

// In Java Classes Are By Default Inner
// Inner Classes
//      Class Defined Inside A Class
//      Inner Class Captures Outer Class Context
class CarAgain(val carName: String) { // Outer Class Context i.e. Enclosing Context
    val category: String = "Family Car"
    override fun toString(): String {
        return "$carName"
    }
    // Nested Class
    // Class Defined Inside A Class
    inner class Engine(val engineName: String) { // Nested Class Context i.e. Enclosed Context
        override fun toString(): String {
            return "Car $carName Have $engineName Engine And It's $category"
        }
    }
}

fun playWithNestedAndInnerClasses() {
    val mazda = Car("Mazda")
    val mazdaEngine = Car.Engine("BMW")
    println("Car : $mazda")
    println("Car Have Engine : $mazdaEngine")

    val mazdaAgain = CarAgain("Mazda")
    val mazdaEngineAgain = mazdaAgain.Engine("BMW")
    println("Car : $mazdaAgain")
    println("Car Have Engine : $mazdaEngineAgain")
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

fun getFacebookName(accountID: Int) = "FB:$accountID"

interface UserInterface {
    val nickName: String
}

class PrivateUser(override val nickName: String) : UserInterface
class SubscribingUser(val email: String) : UserInterface {
    override val nickName: String
        get() = email.substringBefore('@')
}
class FacebookUser(val accountID: Int) : UserInterface {
    override val nickName = getFacebookName(accountID)
}

fun playWithInterfaceProperties() {
    println( PrivateUser("testing@gmail.com").nickName )
    println( SubscribingUser("testing@gmail.com").nickName )
}

//________________________________________________________

interface UserAgainInterface {
    val email: String
    val nickName : String
        get() = email.substringBefore('@')

    var name : String
        get() = "Hello!"
        set(value) {
            println("Can't Save State...")
        }
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

class Employee(val name: String) {
    var address: String = "Unknown"
        get() {
            println("Getter Getting Called, Field Value: $field")
            return field
        }
        set(value: String) {
            println("Setter Getting Called, Field Before Setting: $field")
            field = value // field is Backing Field Or Member Variable
            println("Setter Getting Called, Field After Setting: $field")
        }
}

fun playWithBackingField() {
    val employee = Employee("Alice Carol")
    employee.address = "New York, USA"
    print(employee.address)
}

//________________________________________________________

class LengthCounter {
    var counter: Int = 0
        private  set // Make Setter Private

    fun addWord(word: String) {
        counter += word.length
    }
}

//________________________________________________________
//________________________________________________________

fun main() {
    println("\nFunction : playWithClasses")
    playWithClasses()

    println("\nFunction : playWihInterfaces")
    playWihInterfaces()

    println("\nFunction : playWihInterfaces")
    playWihInterfaces()

    println("\nFunction : playWithClientClass")
    playWithClientClass()

    println("\nFunction : playWithClientAgainDataClass")
    playWithClientAgainDataClass()

    println("\nFunction : playWithColors")
    playWithColors()

    println("\nFunction : playWithEval")
    playWithEval()

    println("\nFunction : playWithEvaluateAgainUsingSealedClases")
    playWithEvaluateAgainUsingSealedClases()

    println("\nFunction : playWithGeometries")
    playWithGeometries()

    println("\nFunction : playWithNestedAndInnerClasses")
    playWithNestedAndInnerClasses()

    println("\nFunction : playWithInterfaceProperties")
    playWithInterfaceProperties()

    println("\nFunction : playWithBackingField")
    playWithBackingField()
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}