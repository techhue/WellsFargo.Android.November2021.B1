package com.example.learnkotlin

import java.lang.IllegalArgumentException

/*
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar
*/

// ____________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

fun playWithCollectionsInKotlin() {
    val set = hashSetOf(10, 20, 30, 80)
    val list = arrayListOf(10, 20, 30, 90)
    val map = hashMapOf( 1 to "One", 2 to "Two", 10 to "Ten")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "elephant", "atom")
    println(strings.last())
    val numbers = setOf(100, 200 ,200, 900)
    println(numbers.maxOrNull())
    println(strings.javaClass)
    println(numbers.javaClass)
//    class java.util.HashSet
//    class java.util.ArrayList
//    class java.util.HashMap
//    atom
//    900
//    class java.util.Arrays$ArrayL
//    class java.util.LinkedHashSet
}

// Parametric Types In Type Theory
// Generics or Templates
// T Is A Type Placeholder
//      Compiler Will Substitute T Placeholder Value With Type
fun <T> joinToString(
   collection: Collection<T>,
   separator : String,
   prefix: String,
   postfix: String
): String {
    val result = StringBuilder( prefix )
    for( (index, element) in collection.withIndex() ) {
        if ( index > 0 ) result.append(separator)
        result.append(element)
    }
    result.append(postfix)
    return result.toString()
}

fun playWithJoinToString() {
    val list = listOf( 10, 20, 30, 100, 90) // List<Int>
    println( joinToString( list, " ; ", " [ ", " ] ") )

    val strings = listOf("first", "second", "elephant", "atom") // List<String>
    println( joinToString(strings, " : ", " [ ", " ] ") )
}

//fun joinToString(
//    collection: Collection<Int>,
//    separator : String,
//    prefix: String,
//    postfix: String
//): String {
//    val result = StringBuilder( prefix )
//    for( (index, element) in collection.withIndex() ) {
//        if ( index > 0 ) result.append(separator)
//        result.append(element)
//    }
//    result.append(postfix)
//    return result.toString()
//}
//
//fun joinToString(
//    collection: Collection<String>,
//    separator : String,
//    prefix: String,
//    postfix: String
//): String {
//    val result = StringBuilder( prefix )
//    for( (index, element) in collection.withIndex() ) {
//        if ( index > 0 ) result.append(separator)
//        result.append(element)
//    }
//    result.append(postfix)
//    return result.toString()
//}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

fun lastChar(string: String) : Char = string.get( string.length - 1 )

// Extension Functions
//     lastCharacter() Is An Extension Function On Type String
//     Used To Add Additional Functionality To EXISTING Class
//     Added Functionality Will Be Available In Whole Code Base
fun String.lastCharacter() : Char = this.get( this.length - 1)

fun playWithLastChar() {
    val greeting = "Good Morning!"
    println( lastChar(greeting))
    println( lastChar("World Is Awesome###"))
//    println( greeting.lastChar())
//    println( greeting.lastChar())

    println( greeting.lastCharacter() )
    println( "World Is Awesome###".lastCharacter() )
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// Extension Functions
//     joinToStringExtension() Is An Extension Function On Type Collection<T>
//     Used To Add Additional Functionality To EXISTING Class
//     Added Functionality Will Be Available In Whole Code Base

// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!
fun <T> Collection<T>.joinToStringExtension(
    separator : String = ", ", // Arguments With Default Values
    prefix: String = "",
    postfix: String = ""
): String {
    val result = StringBuilder( prefix )
    for( (index, element) in this.withIndex() ) {
        if ( index > 0 ) result.append(separator)
        result.append(element)
    }
    result.append(postfix)
    return result.toString()
}

fun playWithJoinToStringExtension() {
    val list = listOf( 10, 20, 30, 100, 90) // List<Int>
    println( list.joinToStringExtension( " ; ", " [ ", " ] ") )
    println( list.joinToStringExtension() )
    println( list.joinToStringExtension( " ## " ) )

    val strings = listOf("first", "second", "elephant", "atom") // List<String>
    println( strings.joinToStringExtension(" : ", " [ ", " ] ") )
//    println( strings.joinToString(" : ", " [ ", " ] ") )
    println( strings.joinToStringExtension() )
    println( strings.joinToStringExtension( " ## " ) )
}

fun <T> Collection<T>.join(
    separator : String,
    prefix: String,
    postfix: String
) = joinToStringExtension( separator, prefix, postfix)

fun playWithJoinFunction() {
    val list = listOf( 10, 20, 30, 100, 90) // List<Int>
    println( list.join( " ; ", " [ ", " ] ") )

    val strings = listOf("first", "second", "elephant", "atom") // List<String>
    println( strings.join(" : ", " [ ", " ] ") )
//    println( strings.joinToString(" : ", " [ ", " ] ") )
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!
// Extension Properties
//      lastChar Is An Extension Property On Type String
val String.lastChar : Char
    get() = get( length - 1)

//      lastChar Is An Extension Property On Type StringBuilder
var StringBuilder.lastChar : Char
    get() = get( length - 1 )
    set( value: Char) {
        this.setCharAt( length - 1, value)
    }

fun playWithExtensionProperties() {
    val greeting = "Good Morning!"
    println( greeting.lastChar )
    println( "World Is Awesome###".lastChar )

    val sb = StringBuilder("Guten Tag")
    println( sb.lastChar )
    println( "World Is Awesome###".lastChar )
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// class User(val id: Int, val name: String, val address: String)

fun saveUser(user: User) {
    if (user.name.isEmpty()) {
        throw IllegalArgumentException("User Name is Empty")
    }
    if (user.address.isEmpty()) {
        throw IllegalArgumentException("User Address is Empty")
    }
    // Logic For Saving User Data...
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// class Is A Keyword To Create A Type
// Created A User Type
class User(val id: Int, val name: String, val address: String)

fun saveUserWithLocalFunction(user: User) {
    // Design Principle
    //      DRY : Don't Repeat Yourself
    // Local Function
    //      Function Defined Inside Function
    fun validate(user: User, value: String, field: String) {
        if (value.isEmpty()) {
            throw IllegalArgumentException("User $field is Empty")
        }
    }
    validate(user, user.name, "Name")
    validate(user, user.address, "Address")
    // Logic For Saving User Data...
}

fun User.validateAndSave() {
    // Design Principle
    //      DRY : Don't Repeat Yourself
    // Local Function
    //      Function Defined Inside Function
    fun validate(value: String, field: String) {
        if (value.isEmpty()) {
            throw IllegalArgumentException("User $field is Empty")
        }
    }
//    validate(this, this.name, "Name")
//    validate(this, this.address, "Address")
    // Logic For Saving User Data...
}

fun playWithSaveUser() {
    val sibi = User(100, "Sibi", "India")
    val esey = User(101, "Esey", "US")
    saveUserWithLocalFunction(sibi)
    saveUserWithLocalFunction(esey)
}

fun main() {
    println("\nFunction : playWithCollectionsInKotlin")
    playWithCollectionsInKotlin()

    println("\nFunction : playWithJoinToString")
    playWithJoinToString()

    println("\nFunction : playWithLastChar")
    playWithLastChar()

    println("\nFunction : playWithJoinToStringExtension")
    playWithJoinToStringExtension()

    println("\nFunction : playWithJoinFunction")
    playWithJoinFunction()

    println("\nFunction : playWithExtensionProperties")
    playWithExtensionProperties()

    println("\nFunction : playWithSaveUser")
    playWithSaveUser()
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}