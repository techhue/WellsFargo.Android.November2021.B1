package com.example.learnkotlin

// Design Principle
//      Classes Which Are Not Meant To Be Inherited Must Be Final
//      Functions Which Are Not Meant To Be Overriden Must Be Final

// In Kotlin
//      Classes And Member Functions Are Final By Default
//      i.e. Closed For Inheritance

// In Java
//      Classes And Member Functions Are Open By Default
//      i.e. Open For Inheritance

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

open class View {
   open fun click() = println("View Clicked!!!")
}

// Inheritance Creates
//      Relationships Between Types
//          Type of Type Relationship
class Button : View() { // Inheritance
    override fun click() = println("Button Clicked!!!")
    fun doMagic() = println("Button Magic...")
}

fun playWithClasses() {
    // 1. Type Inferencing From RHS
    // 2. Type Binding To LHS

    // Following Both Lines Are Equivalent
//    val view : View = View()
    val view  = View()
    view.click()

    // Following Both Lines Are Equivalent
//    val button : Button = Button()
    val button = Button()
    button.click()
    button.doMagic()

    //  Parent Type Will Set The Perceptives
    // Following Both Lines Are Not Same
    val viewAgain: View = Button() // Explicitly Annotating Type To View
//    val viewAgain = Button()

    viewAgain.click()
    //viewAgain.doMagic()
}

fun main() {
    println("\nFunction : playWithClasses")
    playWithClasses()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}