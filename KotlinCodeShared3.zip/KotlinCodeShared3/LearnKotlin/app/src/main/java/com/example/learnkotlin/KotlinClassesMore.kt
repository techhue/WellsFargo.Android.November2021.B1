package com.example.learnkotlin

//               Primary Constructor
data class Grade(val letter: Char, val points: Double, val credits: Double)
//                      constructor Keyword Is Optional
//                      Primary Constructor

// Inheritance Problems
//       Fragile Base Classes
//       Subtraction Is Hard
//       Each Class In Iheritance Diagram Is Not Single Unit
//              Singe Unit Means Class Exists Without Existence Of Any Other Class
open class PersonAgain constructor(var firstName: String, var lastName: String) {
    fun fullName() = "$firstName $lastName"
}

open class Student(
    firstName: String,
    lastName: String,
    var grades: MutableList<Grade> = mutableListOf<Grade>()
) : PersonAgain(firstName, lastName) {
    fun recordGrade(grade: Grade) {
        grades.add(grade)
    }
}

fun playWithClassesAndObjects() {
    val john = PersonAgain(firstName = "Jonny", lastName= "Micheal")
    john.fullName()

    val alice = Student(firstName = "Alice", lastName =  "Carol")
    val history = Grade(letter = 'B', points = 9.0, credits =  3.0)
    alice.recordGrade(history)
}

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    open val minimumPracticeTime: Int
        get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    override val minimumPracticeTime: Int = super.minimumPracticeTime + 10
}

fun playWithRuntimeTypeCheck() {
    val guitarPlayer = GuitarPlayer( firstName = "Esey", lastName = "Woldeabzghi")
    var bandMonitor = Student(firstName =  "Alice", lastName =  "Carol")

    bandMonitor = guitarPlayer
    println( bandMonitor is GuitarPlayer )
    println( bandMonitor !is GuitarPlayer )
    println( bandMonitor is BandMember )
    println( bandMonitor is Student )
    println( bandMonitor is PersonAgain )

    val something = bandMonitor as? BandMember
    println( something?.minimumPracticeTime )
}

fun main() {

    println("\nFunction : playWithClassesAndObjects")
    playWithClassesAndObjects()

    println("\nFunction : playWithRuntimeTypeCheck")
    playWithRuntimeTypeCheck()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}