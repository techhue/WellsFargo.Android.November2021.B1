package com.example.learnkotlin

// Design Principle and Best Practices
//      Classes Which Are Not Meant To Be Inherited Must Be Final
//      Functions Which Are Not Meant To Be Overriden Must Be Final

// In Kotlin
//      Classes And Member Functions Are Final By Default
//      i.e. Closed For Inheritance

// In Java
//      Classes And Member Functions Are Open By Default
//      i.e. Open For Inheritance

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

open class View {
   open fun click() = println("View Clicked!!!")
}

// Inheritance Creates
//      Relationships Between Types
//          Type of Type Relationship
class Button : View() { // Inheritance
    override fun click() = println("Button Clicked!!!")
    fun doMagic() = println("Button Magic...")
}

// Extension Functions Are Bound With Type
//      Extension Functions Can't Be Overridden By Inherited Type

fun View.showOff()   = println("View ShowOff...")
fun Button.showOff() = println("Button ShowOff...")

fun playWithClasses() {
    // 1. Type Inferencing From RHS
    // 2. Type Binding To LHS

    // Following Both Lines Are Equivalent
//    val view : View = View()
    val view  = View()
    view.click()

    // Following Both Lines Are Equivalent
//    val button : Button = Button()
    val button = Button()
    button.click()
    button.doMagic()

    // Parent Type Will Set The Perceptives
    // Following Both Lines Are Not Same
    val viewAgain: View = Button() // Explicitly Annotating Type To View
//    val viewAgain = Button()

    viewAgain.click()
    //viewAgain.doMagic()

//    fun View.showOff()   = println("View ShowOff...")
//    fun Button.showOff() = println("Button ShowOff...")
    view.showOff()
    button.showOff()
    viewAgain.showOff()

//    View ShowOff...
//    Button ShowOff...
//    View ShowOff...
}

// In Kotlin
//      Interfaces And Member Functions Are Opem By Default
//      Implementing Class Must Override It
//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

interface Clickable {
    fun click()
    fun showOff() = println("Clickable ShowOff...")
}

interface Focusable {
    // Provide Default Implementation Only In Rarest Rare Case
    fun setFocus() = println("Focusable setFocus...") // Default Implementation
    fun showOff()  = println("Focusable ShowOff...")
}

open class ButtonAgain : Clickable, Focusable {
    override fun click() = println("ButtonAgain Clicked!!!")
    override fun showOff() {
        // Pick Based On Your Own Custom Logic
        super<Focusable>.showOff()
        super<Clickable>.showOff()
    }
}

open class RichButton : ButtonAgain() {
    final override fun click() = println("RichButton Clicked!!!")
}

class ExtensiveRichButton : RichButton() {
//    override fun click() = println("RichButton Clicked!!!")
//    fun click() = println("RichButton Clicked!!!")
}

fun playWihInterfaces() {
    val button = ButtonAgain()
    button.click()
    button.setFocus()
    button.showOff()

    val richButton = RichButton()
    richButton.click()
}

//_________________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// In Java/Kotlin Every Class By Default Subclass Of Object Class
//      toString(), equals() and hashCode() Methods Comes From Object Class
//      equals() and hashCode() Both Methods Must Be Overridden Together
class Client(val name: String, val postalCode: Int)  {
    override fun toString() = "Client(name=$name, postalCode=$postalCode)"

    override fun equals(other: Any?) : Boolean {
        if (other == null || other !is Client ) return false
        return name == other.name && postalCode == other.postalCode
    }
    // If You Are Overriding equals() Method
    // Than You Must Override hashCode() Method Also
}

fun playWithClientClass() {
    val client1 = Client("Alice", 77777 )
    val client2 = Client("Alice", 77777 )
    val client3 = Client("Alisha", 88888 )

    println(client1) // println Invokes client1.toString()
//    println(client1.name)
//    println(client1.postalCode)
    println(client2) // println Invokes client2.toString()
    println(client3) // println Invokes client3.toString()
//    com.example.learnkotlin.Client@506e6d5e
//    com.example.learnkotlin.Client@96532d6
//    com.example.learnkotlin.Client@3796751b

    // By Default
    // Equality Operator Will Compare References Of The Objects
    // To Compare Objects Based On Properties
    //      Must Override equals() Method
    // Expected True
    // Expected False
    println( client1 == client2 ) // client1.equals(client2)
    println( client1 == client3 ) // client1.equals(client3)
}

//________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// Data Class
// For Data Classes
//      Compiler Will Generate Following Methods Code
//      toString(), equals(), hashCode() and
//      copy() Method Code Generated For Immutable Properties
//          Based On All The Properties
data class ClientAgain(val name: String, val postalCode: Int)

fun playWithClientAgainDataClass() {
    val client1 = ClientAgain("Alice", 77777 )
    val client2 = ClientAgain("Alice", 77777 )
    val client3 = ClientAgain("Alisha", 88888 )

    println(client1) // println Invokes client1.toString()
    println(client2) // println Invokes client2.toString()
    println(client3) // println Invokes client3.toString()

    println( client1 == client2 ) // client1.equals(client2)
    println( client1 == client3 ) // client1.equals(client3)
}

//________________________________________________________

fun main() {
    println("\nFunction : playWithClasses")
    playWithClasses()

    println("\nFunction : playWihInterfaces")
    playWihInterfaces()

    println("\nFunction : playWihInterfaces")
    playWihInterfaces()

    println("\nFunction : playWithClientClass")
    playWithClientClass()

    println("\nFunction : playWithClientAgainDataClass")
    playWithClientAgainDataClass()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}