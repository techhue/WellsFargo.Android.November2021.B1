package com.example.learnkotlin

// Design Principle
//      Design Towards Interfaces Rather Than Concrete Classes

interface Superpower {
    fun fly()
    fun saveWorld()
}

// Single Unit
// Unit Testable
// Spiderman Becoming Type of Superpower
// Creating Type of Type Relationship
class Spiderman : Superpower {
    override fun fly()       = println("Fly Like Spiderman!!!")
    override fun saveWorld() = println("SaveWorld Like Spiderman!!!")
}

// Single Unit
// Unit Testable
class BadSuperman : Superpower {
    override fun fly()       = println("Fly Like Superman!!!")
    override fun saveWorld() = println("SaveWorld Like Superman!!!")
}

class Superman : Superpower {
    override fun fly()       = println("Fly Like Superman!!!")
    override fun saveWorld() = println("SaveWorld Like Superman!!!")
}

// Single Unit
// Unit Testable
class Heman : Superpower {
    override fun fly()       = println("Fly Like Heman!!!")
    override fun saveWorld() = println("SaveWorld Like Heman!!!")
}

// Single Unit
// Unit Testable
class WonderWoman : Superpower {
    override fun fly()       = println("Fly Like WonderWoman!!!")
    override fun saveWorld() = println("SaveWorld Like WonderWoman!!!")
}

// Emergent Principles
// Design Principles SOLID
//      1. Single Responsibility Design
//      2. Open-CLose Principle Design
//          Classes Open Extension But Closed For Modification
// Violates Open-Close Principle

// Polymorphism
//      Mechanism : Composition Design Pattern
//          Using Embedding Object Itself
//          i.e. Human Type Is Polymorphic


class Human { // Delegator
    var power: Superpower? = null   // power Acts As Delegate
    // ?. Is A Safe Access Operator
    fun fly()       = power?.fly()          // if ( power != null ) power.fly() else null
    fun saveWorld() = power?.saveWorld()    // if ( power != null ) power.saveWorld() else null
}

// Composition Design Pattern Is Supported At Language Syntax Level
//      After by Keyword Specify Delegate
class HumanFresh(power: Superpower) : Superpower by power // {
//    var power: Superpower = power
//    fun fly()       = power.fly()
//    fun saveWorld() = power.saveWorld()
//}

// Using Inheritance
//class ChangingHuman : Spiderman() {
//    override fun fly()       = super.fly()
//    override fun saveWorld() = super.saveWorld()
//}

fun main() {
//    val h = ChangingHuman()
//    h.fly()
//    h.saveWorld()

    val human = Human()
    human.power = Spiderman() // Configure As Spiderman
    human.fly()
    human.saveWorld()

    // Inferred Type From RHS Will Be Spiderman
    // Bound Type With LHS Is Spiderman?
//    human.power = BadSuperman() // Configure As Superman
    human.power = Superman() // Configure As Superman
    human.fly()
    human.saveWorld()

    human.power = Heman() // Configure As Heman
    human.fly()
    human.saveWorld()

    human.power = WonderWoman()
    human.fly()
    human.saveWorld()

    val humanAgain = Human()
    humanAgain.fly()
    humanAgain.saveWorld()

    val humanFresh = HumanFresh(Spiderman())
    humanFresh.fly()
    humanFresh.saveWorld()
}
