package com.example.learnkotlin

// Design Principle
//      Design Towards Non Nullability Rather Than Nullability
fun playWithNullability() {
    // Non Nullable
    var name = "Alice" // String
    var age = 900 // Int
    var occupation = "Software Engineer" // String

    // Non Nullable Type
    var errorCode: Int? = 10
    errorCode = 100
    print(errorCode)

    var authorName : String? = "Alice Carol"
    // Following Two Lines Of Code Are Equivalent
    val authorLength = if ( authorName != null ) authorName.length else 0
    // ?: Elvis Operator Followed By Default Value
    val authorLengthAgain = authorName?.length ?: 0

    // Java Style Might Lead To NullPointerExcpetion
    val authorLenghUnsafe = authorName!!.length

    println(authorLength)
    println(authorLengthAgain)
}

//______________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

class Address(val streetAddress: String, val zipCode: Int,
                    val city: String, val country: String)

class Company(val name: String, val address: Address? )
class EmployeeAgain(val name: String, val company: Company? )

fun playWithOptionalChaining() {
    val address = Address("RMZ Ecospace", 560001, "Bangalore", "India")
    val company = Company("Google", address )
    val employee = EmployeeAgain( "Alice", company)

        // Design Principle
        //      Flat System Is Better Than Nested System
        // Optional Chaining
    val country: String? = employee.company?.address?.country
}

//______________________________________________________________

fun main() {
    println("\nFunction : playWithNullability")
    playWithNullability()

    println("\nFunction : playWithOptionalChaining")
    playWithOptionalChaining()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")

}

