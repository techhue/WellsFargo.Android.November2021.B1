package com.example.learnkotlin

import java.lang.IndexOutOfBoundsException

//data class Point(var x: Int, var y: Int ) {
//    operator fun plus(other: Point) : Point {
//        return Point( x + other.x, y + other.y )
//    }
//}

operator fun Point.minus(other: Point) : Point {
    return Point( x - other.x, y - other.y )
}

operator fun Point.get(index: Int) : Int {
    return when(index) {
        0 -> x
        1 -> y
        else -> throw IndexOutOfBoundsException("Index Out Of Bound...")
    }
}

operator fun Point.set(index: Int, value: Int) {
    return when(index) {
        0 -> x = value
        1 -> y = value
        else -> throw IndexOutOfBoundsException("Index Out Of Bound...")
    }
}

fun playWithOperators() {
    val point1 = Point(10, 20)
    val point2 = Point(100, 200)
    println(point1)
    println(point1)

    val point3 = point1 + point2 // point1.plus(point2)
    println(point3)

    val point4 = point1 - point2 // point1.plus(point2)
    println(point4)

    println(point3[0])
    println(point3[1])

    point3[0] = 111
    point3[1] = 222

    println(point3[0])
    println(point3[1])
}

//______________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!
data class Point(var x: Int, var y: Int ) {
    operator fun plus(other: Point) : Point {
        return Point( x + other.x, y + other.y )
    }
}

data class RectangleNew(val upperLeft: Point, val lowerRight: Point)
operator fun RectangleNew.contains(point : Point) : Boolean {
    return point.x in upperLeft.x until lowerRight.x &&
            point.y in upperLeft.y until lowerRight.y
}

fun playWithPointInsideRectangle() {
    val rectangle = RectangleNew( Point(10, 20), Point(100, 200))
    val point = Point(50, 50)
    val pointAgain = Point(0, 0)

    println( point in rectangle )       // rectangle.contains(point)
    println( pointAgain in rectangle )  // rectangle.contains(pointAgain )
}

//______________________________________________________________

fun main() {

    println("\nFunction : playWithOperators")
    playWithOperators()

    println("\nFunction : playWithPointInsideRectangle")
    playWithPointInsideRectangle()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")

}

