package com.example.learnkotlin

import java.lang.StringBuilder

//______________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

fun sum(x: Int, y: Int ) = x + y
fun sub(x: Int, y: Int ) = x - y
// Higher Order Function
//      Function Which Takes Function As Argument
fun calculator(x: Int, y: Int, operate: (Int, Int) -> Int ) : Int {
    return operate(x, y)
}

fun playWithCalculator() {
    val a = 50
    val b = 20
    var result : Int

    result = calculator(a, b, ::sum) // ::sum Is Reference Of sum Function
    println(result)

    result = calculator(a, b, ::sub) // ::sub Is Reference Of sub Function
    println(result)

    val sumLambda = { x: Int, y: Int -> x + y }
    val subLambda = { x: Int, y: Int -> x - y }

    result = calculator(a, b, sumLambda) // ::sum Is Reference Of sum Function
    println(result)

    result = calculator(a, b, subLambda) // ::sub Is Reference Of sub Function
    println(result)
}

//______________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// Higher Order Function
//      Function Which Returns Function
fun chooseSteps(forward: Boolean) : (Int) -> Int  {
    fun moveForward(steps: Int) : Int {
        return steps + 1
    }
    fun moveBackward(steps: Int) : Int {
        return steps - 1
    }

    return if (forward) ::moveForward else ::moveBackward
}

fun playWithChoices() {
    val doMagic1 = chooseSteps(true)
    println( doMagic1(10) )
    println( doMagic1(11) )

    val doMagic2 = chooseSteps(false)
    println( doMagic2(10) )
    println( doMagic2(11) )
}

//______________________________________________________________

// Not A Pure Function Becuse println Creates Side Effect
fun doSomething() {
    val a = 20
    val b = 30
    println("Hello!") // stdout
}

//______________________________________________________________

// Pure Function
fun String.filter(predicate: (Char) -> Boolean)  : String {
    val sb = StringBuilder()
    for( index in 0 until length) {
        val element = get(index)
        if( predicate(element) ) sb.append(element)
    }
    return sb.toString()
}

fun playWithPureFunction() {
    val something = "abcd897ABCuuummUU009"
    val result = something.filter( { xx: Char -> xx in 'a'..'z'} )
    println(result)
}

//______________________________________________________________

fun main() {
    println("\nFunction : playWithCalculator")
    playWithCalculator()

    println("\nFunction : playWithChoices")
    playWithChoices()

    println("\nFunction : playWithPureFunction")
    playWithPureFunction()
//    println("\nFunction : ")
//    println("\nFunction : ")
}

