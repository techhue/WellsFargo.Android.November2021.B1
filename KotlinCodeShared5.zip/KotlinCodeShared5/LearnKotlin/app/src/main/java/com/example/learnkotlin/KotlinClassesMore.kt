package com.example.learnkotlin

//               Primary Constructor
data class Grade(val letter: Char, val points: Double, val credits: Double)
//                      constructor Keyword Is Optional
//                      Primary Constructor

// Inheritance Problems
//       Fragile Base Classes
//       Subtraction Is Hard
//       Each Class In Inheritance Diagram Is Not Single Unit
//              Singe Unit Means Class Exists Without Existence Of Any Other Class
open class PersonAgain constructor(var firstName: String, var lastName: String) {
    fun fullName() = "$firstName $lastName"
}

open class Student(
    firstName: String,
    lastName: String,
    var grades: MutableList<Grade> = mutableListOf<Grade>()
) : PersonAgain(firstName, lastName) {
    fun recordGrade(grade: Grade) {
        grades.add(grade)
    }
}

fun playWithClassesAndObjects() {
    val john = PersonAgain(firstName = "Jonny", lastName= "Micheal")
    john.fullName()

    val alice = Student(firstName = "Alice", lastName =  "Carol")
    val history = Grade(letter = 'B', points = 9.0, credits =  3.0)
    alice.recordGrade(history)
}

open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    open val minimumPracticeTime: Int
        get() { return 2 }
}

class GuitarPlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    override val minimumPracticeTime: Int = super.minimumPracticeTime + 10
}

fun playWithRuntimeTypeCheck() {
    val guitarPlayer = GuitarPlayer( firstName = "Esey", lastName = "Woldeabzghi")
    var bandMonitor = Student(firstName =  "Alice", lastName =  "Carol")

    bandMonitor = guitarPlayer
    println( bandMonitor is GuitarPlayer )
    println( bandMonitor !is GuitarPlayer )
    println( bandMonitor is BandMember )
    println( bandMonitor is Student )
    println( bandMonitor is PersonAgain )

    val somethingAgain = bandMonitor as BandMember
    val something = bandMonitor as? BandMember
    println( something?.minimumPracticeTime )
}
// _____________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!
// Polymorphism
//      Mechanism : Function Overloading
fun afterClassActivity(student: Student): String {
    return "Goes To The Home!"
}

fun afterClassActivityAgain(student: Student) = "Goes To The Home!"

fun afterClassActivity(student: BandMember) : String {
    return "Goes To The Practice!"
}

fun playWithPolymorphicFunctions() {
    val guitarPlayer = GuitarPlayer( firstName = "Esey", lastName = "Woldeabzghi")
    val studentAlice = Student(firstName =  "Alice", lastName =  "Carol")

    println( afterClassActivity(guitarPlayer) )
    println( afterClassActivity(guitarPlayer) )

    println( afterClassActivity(studentAlice) )
    println( afterClassActivity(studentAlice) )
}

// _____________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

// Abstract Classes
abstract  class Mammal(val birthDate: String) {
    abstract  fun consumeFood()
}

// Concrete Class
class HumanNew(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() {
        println("Eating Food...")
    }

    fun createBirthCertificate() {
        println("Creating Birth Certificate...")
    }
}

fun playWithHumanNew() {
    val human = HumanNew(birthDate = "01/01/2020")
    human.consumeFood()
    human.createBirthCertificate()
}

// _____________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

data class Priviledge(val id: Int, val name: String)

open class UserAgain(val username: String, private  val id: String, protected var age: Int)

class PrivilegedUser(username: String, id: String, age: Int) : UserAgain(username, id, age) {
    private val privileges = mutableListOf<Priviledge>()

    fun addPrivilege(privilege: Priviledge) {
        privileges.add(privilege)
    }

    fun hasPrivilege(id: Int) : Boolean {
        return privileges.map { it.id }.contains(id)
    }
}

fun playWithVisibility() {
    val priviledgedUser = PrivilegedUser(username =  "Alice Carol", id = "1000", age = 25)
    val privilege = Priviledge(1, "Access Granted")
    priviledgedUser.addPrivilege(privilege)
}
// _____________________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE!

fun main() {
    println("\nFunction : playWithClassesAndObjects")
    playWithClassesAndObjects()

    println("\nFunction : playWithRuntimeTypeCheck")
    playWithRuntimeTypeCheck()

    println("\nFunction : playWithPolymorphicFunctions")
    playWithPolymorphicFunctions()

    println("\nFunction : playWithHumanNew")
    playWithHumanNew()

    println("\nFunction : playWithVisibility")
    playWithVisibility()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}