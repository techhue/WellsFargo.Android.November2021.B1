package com.example.learnkotlin

import java.util.Random
import java.util.TreeMap

// __________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE

// Function Which Doesn't Take Any Argument
//      Returns Unit Value Of Unit Type
fun helloWorld() {
    println("Hello World!!!")
}

// In Java
//      if-else Is A Statement
// In Kotlin
//      if-else Construct Is An Expression
//      Expression Is A Statement With Return Value

// Function Taking 2 Int Arguments And Returning Int
fun max(a: Int, b: Int) : Int {
    return if ( a > b ) a else b
}

// Function Is First Class Citizen
//      Function Can Be Assigned A Value
// Compile Type Decision
// 1. Type Inferencing From RHS
// 2. Type Binding To LHS
fun maximum(a: Int, b: Int) = if ( a > b ) a else b

fun playWithMax() {
    println( max( 100, 200) )
    println( max( -900, 900) )

    println( maximum( 100, 200) )
    println( maximum( -900, 900) )
}

//fun playWithMax() { println( max( a: 100, b: 200 ));
//    println( max( a: -900, b: 900 ))
//}

// val Means IMMUTABLE
// var Means MUTABLE
// With class Keyword
//      Creating Person Type
//          Having Two Properties viz. name And isMarried
//      Compiler Will Generate
//          Getter and Setters For name And isMarried
//              For name Only Getter Generated
//              For isMarried Both Getter and Setters Will Be Generated
//          Constructor i.e. Memberwise Initializer

// __________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE
//
class Person(val name: String, var isMarried: Boolean)

fun playWithPerson() {
    val person = Person("Alice", false)
    println(person.name) // person.getName()
    println(person.isMarried) // person.getIsMarried()

   // person.name = "Alice Carol"
    person.isMarried = true // person.setIsMarried(true)

    println(person.name)
    println(person.isMarried)
}

// __________________________________________________
// PLEASE RAISE YOUR HAND MOMENT YOU ARE DONE

class Rectangle(val height: Int, val width: Int) {
    val isSquare : Boolean // Computed Property
        get() { // Custom Getter
            return height == width
        }
}

// import java.util.Random
fun playWithRectangle() {
    var rectangle = Rectangle(100, 200)
    println( rectangle.height )
    println( rectangle.width )
    println( rectangle.isSquare )

    rectangle = Rectangle(200, 200)
    println( rectangle.height )
    println( rectangle.width )
    println( rectangle.isSquare )

    val random = Random()
    rectangle = Rectangle( random.nextInt(), random.nextInt() )
    println( rectangle.height )
    println( rectangle.width )
    println( rectangle.isSquare )

}


//____________________________________________________________
// Experiment Following Code and RAISE YOUR HAND MOMENT DONE!

enum class Colour {
    RED, GREEN, BLUE
}

fun playWithColours() {
    println(Colour.RED)
    println(Colour.GREEN)
    println(Colour.BLUE)
}

//____________________________________________________________
// Experiment Following Code and RAISE YOUR HAND MOMENT DONE!

// Created Type Color
// Ramge = {  RED, GREEN, BLUE, ORANGE, YELLOW }
//
enum class Color {
    RED, GREEN, BLUE, ORANGE, YELLOW, UNKNOWN
}

fun getStringForColor(color: Color): String {
    // Fundamental Principle
    // An Type Safe Expression
    //      Respects Type Like God!

    // 'when' expression must be exhaustive,
    // add necessary 'ORANGE' branch or 'else' branch instead
    return when( color ) { // Pattern Matching
        Color.RED   -> "Red Color"
        Color.GREEN -> "Green Color"
        Color.BLUE  -> "Blue Color"
        Color.ORANGE  -> "Orange Color"
        Color.YELLOW  -> "Yellow Color"
        Color.UNKNOWN -> "Unkown Color"
     }
}

fun getStringForColorAgain(color: Color) = when( color ) {
        Color.RED   -> "Red Color"
        Color.GREEN -> "Green Color"
        Color.BLUE  -> "Blue Color"
        else        -> "Unkown Color" // BLACK HOLE
//        else        -> 90
}

fun playWithColorsAgain() {
    println( getStringForColor(Color.RED))
    println( getStringForColor(Color.GREEN))
    println( getStringForColor(Color.BLUE))

    println( getStringForColorAgain(Color.RED))
    println( getStringForColorAgain(Color.GREEN))
    println( getStringForColorAgain(Color.BLUE))
}

// Design Principle
// Exceptions Are Not Exceptional That It Should Break Your Design
fun mixColors(c1: Color, c2: Color) : Color = when ( setOf(c1, c2) ) {
    setOf(Color.RED, Color.GREEN) -> Color.YELLOW
    setOf(Color.RED, Color.BLUE) -> Color.ORANGE
    else -> throw Exception("Unknown Color")
}

// Type Safe Code
// Closure Law
fun mixColorsAgain(c1: Color, c2: Color) : Color = when ( setOf(c1, c2) ) {
    setOf(Color.RED, Color.GREEN) -> Color.YELLOW
    setOf(Color.RED, Color.BLUE)  -> Color.ORANGE
    // else -> throw Exception("Unknown Color")
    // else -> "Unkown Color"
    else -> Color.UNKNOWN
}

fun playWithTypeInferencingAndTypeBinding() {
    // Compile Type Decision
    // 1. Type Inferencing From RHS
    // 2. Type Binding To LHS
    val something = 190
    println(something)

    // Type Annotation
    val somethingAgain: Int = 190
    println(somethingAgain)

    val some = "Hello World"
    println(some)

    val someAgain: String = "Hello World"
    println(someAgain)

    //  This variable must either have a type annotation or be initialized
    val dingDong: String
    dingDong = "Some String"
    println(dingDong)

    val something1 = 90.89
    println(something1)

    val somethingAgain1: Double = 90.89
    println(somethingAgain1)

    val somethingF = 90.89F
    println(somethingF)

    val somethingF1: Float = 90.89F
    println(somethingF1)
}

fun fizzBuzz(number : Int) = when {
    number % 15 == 0 -> "FizzBuzz"
    number % 5  == 0 -> "Fizz"
    number % 3  == 0 -> "Buzz"
    else -> " $number "
}

fun playWithFizzBuzz() {
    for ( number in 1..100 ) {
        print( fizzBuzz(number))
    }

    println()
    for ( number in 100 downTo 1 step 2) {
        print(( fizzBuzz(number)))
    }
}

// BEST PRACTICE
// Always Prefer for-in Loop Rather Than Indexing Loop

// import java.util.TreeMap
fun playWithMapsIteration() {
    val binaryReps = TreeMap<Char, String>()

    for (character in 'A'..'F') {
        val binary = Integer.toBinaryString( character.code )
        binaryReps[character] = binary
    }

    for ( (letter, binary) in binaryReps ) {
        println(" $letter = $binary ")
    }
}

fun main() {
    println("\nFunction : helloWorld")
    helloWorld()

    println("\nFunction : playWithMax")
    playWithMax()

    println("\nFunction : playWithPerson")
    playWithPerson()

    println("\nFunction :  playWithRectangle")
    playWithRectangle()

    println("\nFunction : playWithColors")
    playWithColours()

    println("\nFunction : playWithTypeInferencingAndTypeBinding")
    playWithTypeInferencingAndTypeBinding()

    println("\nFunction : playWithColorsAgain")
    playWithColorsAgain()

    println("\nFunction : playWithFizzBuzz")
    playWithFizzBuzz()

    println("\nFunction : playWithMapsIteration")
    playWithMapsIteration()

//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
//    println("\nFunction : ")
}